<div class="about">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-5">
                  <div class="titlepage">
                     <h2>About Us</h2>
                     <p>Chào mừng quý khách đến với khách sạn Keto, nơi nghỉ dưỡng đẳng cấp với tiện nghi hiện đại và dịch vụ chuyên nghiệp. Tọa lạc tại thủ đô Hà Nội, chúng tôi cung cấp các phòng nghỉ sang trọng, nhà hàng đa dạng và spa thư giãn. Hãy trải nghiệm sự thoải mái và hài lòng tối đa tại khách sạn Keto! </p>
                     <a class="read_more" href="Javascript:void(0)"> Đọc thêm</a>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                     <figure><img src="images/about.png" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>
