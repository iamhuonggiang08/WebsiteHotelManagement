<?php echo e($slot); ?>

<?php /**PATH D:\01. setup\xampp\htdocs\hotelManage\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>