[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\01. setup\xampp\htdocs\hotelManage\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>