<!DOCTYPE html>
<html>
  <head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">

        .table_deg{
            border: 2px solid white;
            margin: auto;
            width: 80%;
            text-align: center;
            margin-top: 40px;
        }

        .th-deg{
            background-color: skyblue;
            padding: 15px;
        }

        tr{
            border: 3px solid white;
        }

        td{
            padding: 10px;
        }

    </style>

  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Sidebar Navigation end-->

    <div class="page-content">
        <div class="page-header">
            <div class="container-fluid">

                <table class="table_deg">

                    <tr>
                        <th class="th-deg">Room Title</th>
                        <th class="th-deg">Description</th>
                        <th class="th-deg">Price</th>
                        <th class="th-deg">Wifi</th>
                        <th class="th-deg">Room Type</th>
                        <th class="th-deg">Image</th>
                        <th class="th-deg">Delete</th>
                        <th class="th-deg">Update</th>
                    </tr>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->room_title); ?></td>
                        <td><?php echo Str::limit($data->description,150); ?></td>
                        <td><?php echo e($data->price); ?>$</td>
                        <td><?php echo e($data->wifi); ?></td>
                        <td><?php echo e($data->room_type); ?></td>

                        <td>
                            <img width="100" src="room/<?php echo e($data->image); ?>" alt="">
                        </td>

                        <td>
                            <a onclick="return confirm('Are you sure to delete this ');" class="btn btn-danger" href="<?php echo e(url('room_delete',$data->id)); ?>">Delete</a>
                        </td>

                        <td>
                            <a class="btn btn-warning" href="<?php echo e(url('room_update',$data->id)); ?>">Update</a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH D:\01. setup\xampp\htdocs\hotelManage\resources\views/admin/view_room.blade.php ENDPATH**/ ?>