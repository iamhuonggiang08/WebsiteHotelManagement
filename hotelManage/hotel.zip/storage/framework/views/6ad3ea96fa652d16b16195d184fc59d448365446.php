 <!-- header inner -->
 <div class="header">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="<?php echo e(url('/')); ?>"><img src="images/logo.png" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                 <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="<?php echo e(url('our_rooms')); ?>">Our room</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="<?php echo e(url('hotel_gallary')); ?>">Gallery</a>
                              </li>

                              <li class="nav-item">
                                 <a class="nav-link" href="<?php echo e(url('contact_us')); ?>">Contact Us</a>
                              </li>









                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>

                        <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

                    <?php else: ?>

                        <li class="nav-item" style="padding-right:10px">
                                 <a class="btn btn-success" href="<?php echo e(url('login')); ?>">Login</a>
                        </li>

                        <?php if(Route::has('register')): ?>

                            <li class="nav-item">
                                 <a class="btn btn-primary" href="<?php echo e(url('register')); ?>">Register</a>
                            </li>

                        <?php endif; ?>
                    <?php endif; ?>

            <?php endif; ?>


                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
<?php /**PATH D:\01. setup\xampp\htdocs\hotelManage\resources\views/home/header.blade.php ENDPATH**/ ?>