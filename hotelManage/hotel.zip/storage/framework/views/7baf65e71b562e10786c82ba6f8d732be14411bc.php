<!DOCTYPE html>
<html>
  <head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">

        .table_deg{
            border: 2px solid white;
            margin: auto;
            width: 80%;
            text-align: center;
            margin-top: 40px;
        }

        .th-deg{
            background-color: skyblue;
            padding: 15px;
        }

        tr{
            border: 3px solid white;
        }

        td{
            padding: 10px;
        }

    </style>

  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Sidebar Navigation end-->

    <div class="page-content">
        <div class="page-header">
           <div class="container-fluid">

           <table class="table_deg">

            <tr>
                <th class="th-deg">Name</th>
                <th class="th-deg">Email</th>
                <th class="th-deg">Phone</th>
                <th class="th-deg">Message</th>
                <th class="th-deg">Send Email</th>
            </tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->message); ?></td>
                <td>
                    <a class="btn btn-success" href="<?php echo e(url('send_mail', $data->id)); ?>">send mail</a>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

           </div>
        </div>
    </div>
    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH D:\01. setup\xampp\htdocs\hotelManage\resources\views/admin/all_message.blade.php ENDPATH**/ ?>